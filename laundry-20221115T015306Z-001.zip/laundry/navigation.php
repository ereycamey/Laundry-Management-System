  <li class="header">MAIN NAVIGATION</li>
           
    <li class="treeview">
      <a href="home.php">
        <i class="fa fa-home"></i>
        <span>Home</span>
      </a>
    </li>

    <li class="treeview">
      <a href="laundrytype.php">
        <i class="fa fa-th-list"></i>
        <span>Laundry List</span>
      </a>
    </li>
  
      </a>
    </li>
    <li class="treeview">
      <a href="category.php">
        <i class="fa fa-th-list"></i>
        <span>Laundry Category</span>
      </a>
    </li>
    <li class="treeview">
      <a href="supply.php">
        <i class="fa fa-th-list"></i>
        <span>Supply List</span>
      </a>
    </li>
     <li class="treeview">
      <a href="inventory.php">
        <i class="fa fa-th-list"></i>
        <span>Inventory</span>
      </a>
    </li>


    <li class="treeview">
      <a href="report.php">
        <i class="fa fa-print"></i>
        <span>Report</span>
      </a>
    </li>
     <li class="treeview">
      <a href="users.php">
        <i class="fa fa-th-list"></i>
        <span>Users</span>
      </a>
    </li>

<li class="header">SETTINGS</li>
	<li><a id="changePass" href="#"><i class="fa fa-circle-o text-yellow"></i> 
		<span>Change Password</span></a>
	</li>

	<li><a href="logout.php"><i class="fa fa-circle-o text-red"></i> 
		<span>Logout</span></a>
	</li>